import{c as a}from"../chunks/entry.DFosKZrm.js";export{a as start};
